#!/usr/bin/env python3
"""Create a blank Markdown table for tracking a person's claims."""

from __future__ import annotations

import argparse
from datetime import date


def build_table(person: str, topic: str | None) -> str:
    title = f"# Claim Tracking Table: {person}"
    if topic:
        title += f" - {topic}"

    lines = [
        title,
        "",
        f"Generated: {date.today().isoformat()}",
        "",
        "| Date | Original Claim or Faithful Paraphrase | Source | Claim Type | Verifiability | Verification Status | Evidence Link | Notes |",
        "| --- | --- | --- | --- | --- | --- | --- | --- |",
        "| YYYY-MM-DD |  |  | fact / prediction / causal / strategy / value / interpretation / positioning | verifiable / partly verifiable / not yet testable / not verifiable / source insufficient | verified / partly verified / unverified / not yet testable / falsified / not verifiable |  |  |",
    ]
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Generate a blank Markdown claim-tracking table."
    )
    parser.add_argument("person", help="Person being researched")
    parser.add_argument("--topic", help="Optional research topic or domain")
    args = parser.parse_args()

    print(build_table(args.person, args.topic))


if __name__ == "__main__":
    main()

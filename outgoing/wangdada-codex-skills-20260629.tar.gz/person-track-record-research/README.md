# Person Track Record Research

[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Codex Skill](https://img.shields.io/badge/Codex-Skill-blue.svg)](SKILL.md)

Evidence-first Codex skill for researching a person's historical viewpoints, predictions, claim accuracy, viewpoint changes, and domain-specific credibility.

## What It Does

This skill helps Codex evaluate whether a public figure, thinker, investor, founder, scholar, journalist, KOL, or commentator has a reliable track record.

It focuses on:

- Dated viewpoint timelines
- Original sources and evidence limits
- Verifiable claims and prediction outcomes
- Viewpoint changes over time
- Domain-specific credibility boundaries
- Risk signals such as vague forecasts, unfalsifiable claims, and poor correction behavior

The core rule is simple: build the evidence record before judging credibility.

## When To Use

Use this skill for prompts like:

- "Research whether this person's past predictions were accurate."
- "Check whether they always held this view or changed recently."
- "Evaluate this commentator's credibility by looking at old claims."
- "Did their earlier judgments get verified by time?"
- "Build a timeline of this person's views on a topic."

## Installation

Clone this repository into your Codex skills directory:

```bash
git clone https://github.com/wangdada8208/person-track-record-research.git ~/.codex/skills/person-track-record-research
```

Then invoke it explicitly:

```text
Use $person-track-record-research to research this person's historical viewpoints and time-tested credibility.
```

Codex may also trigger it implicitly when a request matches the skill description.

## Included Files

- `SKILL.md`: core skill instructions and trigger description
- `references/research-method.md`: detailed research workflow
- `references/claim-taxonomy.md`: claim classification rules
- `references/verification-rubric.md`: verification labels and credibility tiers
- `references/report-template.md`: report structure
- `scripts/create_claim_table.py`: Markdown claim table generator
- `agents/openai.yaml`: Codex UI metadata

## Claim Table Helper

Generate a blank Markdown evidence table:

```bash
python3 scripts/create_claim_table.py "Person Name" --topic "AI predictions"
```

Example output fields include date, original claim, source, claim type, verifiability, verification status, evidence link, and notes.

The script only creates a template. It does not verify claims or assign credibility.

## Credibility Philosophy

The skill does not treat fame, confidence, eloquence, or popularity as credibility evidence.

It also avoids two common mistakes:

- An unverified claim is not automatically false.
- One accurate prediction does not make a person generally trustworthy.

Credibility is assessed by domain and evidence quality, not by a global personality verdict.

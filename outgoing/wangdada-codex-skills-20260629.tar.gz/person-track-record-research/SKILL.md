---
name: person-track-record-research
description: Evidence-first research workflow for evaluating a person's historical viewpoints, predictions, claim accuracy, viewpoint changes, and domain-specific credibility. Use when asked to study whether a person, thinker, investor, founder, scholar, journalist, KOL, public figure, or commentator is trustworthy; whether they have always held a view or recently changed it; whether their past claims were validated by time; or how their judgment record differs by domain.
---

# Person Track Record Research

## Core Rule

Build the evidence record before judging credibility. Do not start with a personality verdict. First collect dated claims, original sources, context, claim types, and verification status; only then offer a bounded credibility assessment.

## Workflow

1. Define the research subject, topic, time range, and domain boundaries.
2. Prefer primary sources: original posts, articles, interviews, speeches, papers, books, transcripts, filings, podcasts, or videos. Use secondary sources only to locate or contextualize primary material.
3. Record each important viewpoint with date, source, context, exact quote or faithful paraphrase, claim type, verifiability, later evidence, and verification status.
4. Separate facts, predictions, causal claims, value judgments, strategy advice, and identity or positioning statements. Read `references/claim-taxonomy.md` when classification matters.
5. Evaluate verification status conservatively. Read `references/verification-rubric.md` before making credibility judgments.
6. Analyze viewpoint change neutrally: distinguish reasonable updating, vague drift, opportunistic reversal, stable core model with changed wording, and corrections after being wrong.
7. Conclude by domain, not globally. A person may be reliable in one field and weak in another.

## Output Order

Use this order unless the user requests a different format:

1. Research object and scope
2. Source note and evidence limits
3. Core viewpoint timeline
4. Verifiable claims
5. Time-tested verification results
6. Viewpoint change analysis
7. Credible domains and boundaries
8. Risk signals
9. Conclusion

For a full report scaffold, read `references/report-template.md`.

## Evidence Standards

- Do not treat an unverified claim as false. Label it `unverified` or `not yet testable`.
- Do not treat fame, confidence, eloquence, or popularity as credibility evidence.
- Do not generalize one accurate prediction into total trustworthiness.
- Mark unavailable, paywalled, deleted, login-only, or secondhand sources as evidence limits.
- Avoid unsupported character claims. Discuss observable behavior: claims, corrections, source quality, incentives, and track record.
- When browsing current or time-sensitive material, verify dates carefully and cite the sources used.

## Optional Table Helper

Use `scripts/create_claim_table.py` to generate a Markdown claim-tracking table:

```bash
python3 scripts/create_claim_table.py "Person Name" --topic "AI predictions"
```

The script creates a blank evidence table only. It does not verify claims or assign credibility.

## References

- `references/research-method.md`: detailed research workflow
- `references/claim-taxonomy.md`: claim classification rules
- `references/verification-rubric.md`: verification labels and credibility tiers
- `references/report-template.md`: final report template

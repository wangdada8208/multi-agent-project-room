# Verification Rubric

Use conservative labels. If the evidence is ambiguous, say so.

## Verification Status

| Label | Meaning |
| --- | --- |
| Verified | The claim substantially matched later evidence or outcomes |
| Partly verified | The claim captured an important direction but missed timing, scale, cause, or conditions |
| Unverified | The claim has not been checked or evidence is insufficient |
| Not yet testable | The claim has a future deadline or horizon that has not arrived |
| Falsified | Later evidence substantially contradicted the claim |
| Not verifiable | The claim is too vague, subjective, or unfalsifiable |

## Viewpoint Change Labels

| Label | Meaning |
| --- | --- |
| Reasonable update | The person revised the view after new evidence and explained why |
| Quiet revision | The view changed, but the person did not clearly acknowledge the change |
| Opportunistic reversal | The change tracks incentives, audience, or fashion more than evidence |
| Stable model | Wording changed but the core view remained consistent |
| Corrective learning | The person was wrong and later incorporated the failure into a better model |
| Persistent error | The person kept repeating a claim after strong contrary evidence |

## Credibility Tiers

Use these as narrative tiers, not mathematical scores.

- `High credibility`: multiple specific claims were verified, uncertainty was handled honestly, and errors were corrected.
- `Conditional credibility`: useful within clear domains or conditions, with mixed or incomplete evidence elsewhere.
- `Under observation`: evidence is too thin, too recent, or mostly not yet testable.
- `Use caution`: repeated strong claims have weak verification, unclear sourcing, or poor correction behavior.
- `Low credibility`: repeated falsified claims, source manipulation, hidden conflicts, deleted reversals, or persistent unfalsifiable claims.

## Risk Signals

Note risk signals separately from the final tier:

- Strong claims without dates or falsifiable conditions
- Frequent certainty where evidence is weak
- Deleted or rewritten claims without disclosure
- Taking credit for correct calls while hiding wrong ones
- Domain hopping after failure
- Conflicts of interest or incentives not disclosed
- Reliance on private information the audience cannot inspect
- Refusal to update after strong contrary evidence

## Important Distinctions

- `Unverified` does not mean false.
- `Falsified` does not mean the person is always unreliable.
- `Accurate once` does not mean generally trustworthy.
- `Changed view` can indicate learning, not hypocrisy.
- `Consistent view` can indicate stubbornness, not wisdom.

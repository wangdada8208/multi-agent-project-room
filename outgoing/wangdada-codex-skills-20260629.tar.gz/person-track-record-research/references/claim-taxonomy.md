# Claim Taxonomy

Classify claims before verification. Different claim types require different evidence.

## Claim Types

| Type | Meaning | Verification Approach |
| --- | --- | --- |
| Fact claim | Says something is or was true | Check records, data, documents, reliable reporting |
| Prediction | Says something will happen | Compare with later outcomes and stated time horizon |
| Causal claim | Says X causes Y | Look for evidence quality, mechanisms, counterexamples, expert consensus |
| Strategy advice | Recommends action | Evaluate outcome, assumptions, audience, and risk conditions |
| Value judgment | Says something is good, bad, fair, desirable | Usually not objectively verifiable; assess consistency and stated values |
| Interpretation | Explains what an event means | Compare with alternative explanations and later evidence |
| Identity or positioning | Signals affiliation, principles, or self-description | Verify consistency through behavior, but avoid overclaiming intent |
| Meta-claim | Claims expertise, uncertainty, or method | Check whether the person's process matches their stated method |

## Verifiability Labels

- `verifiable`: enough specificity and later evidence exists
- `partly verifiable`: some parts can be checked, others are vague or normative
- `not yet testable`: claim has a future horizon that has not arrived
- `not verifiable`: claim is primarily subjective, vague, or unfalsifiable
- `source insufficient`: claim may be verifiable, but available sources are too thin

## Extraction Guidance

Prefer extracting claims that are:

- Dated
- Clear enough to be wrong
- Repeated or central to the person's public model
- Made before the outcome was known
- Influential for followers, investors, voters, readers, or users

Avoid treating rhetorical exaggeration as a precise forecast unless the person repeated it as a serious claim.

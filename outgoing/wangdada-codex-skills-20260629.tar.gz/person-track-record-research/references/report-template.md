# Report Template

Use this structure for full reports. Omit sections only when the user asks for a brief answer.

## Research Object and Scope

- Person:
- Topic or domain:
- Time range:
- Source types:
- Evidence limits:

## Source Note

Briefly state the most important sources used and whether they are primary or secondary. Mention missing, unavailable, paywalled, deleted, or login-only sources.

## Core Viewpoint Timeline

| Date | Viewpoint | Source | Context | Notes |
| --- | --- | --- | --- | --- |
| YYYY-MM-DD |  |  |  |  |

## Verifiable Claims

| Date | Claim | Type | Verifiability | Later Evidence | Status |
| --- | --- | --- | --- | --- | --- |
| YYYY-MM-DD |  |  |  |  |  |

## Time-Tested Results

Summarize:

- Verified claims
- Partly verified claims
- Falsified claims
- Unverified or not-yet-testable claims
- Claims that were never specific enough to test

## Viewpoint Change Analysis

Address:

- Which views remained stable
- Which views changed
- Whether changes were explained
- Whether changes appear evidence-driven, audience-driven, or unclear
- Whether the person acknowledged errors

## Credible Domains and Boundaries

| Domain | Credibility Tier | Evidence Basis | Boundary |
| --- | --- | --- | --- |
|  |  |  |  |

## Risk Signals

List concrete, evidence-backed risk signals. Do not include unsupported character judgments.

## Conclusion

Give a bounded answer:

> Based on the available evidence, this person is most credible on [domain/condition], less reliable on [domain/condition], and should be treated cautiously when [risk condition].

Add uncertainty when the evidence base is incomplete.

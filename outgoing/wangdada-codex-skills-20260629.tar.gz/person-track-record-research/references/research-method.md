# Research Method

Use this workflow when the task requires more than a quick answer.

## 1. Frame the Study

Identify:

- Person or institution being studied
- Domain, such as AI, investing, macroeconomics, politics, education, product strategy, or public health
- Time range
- Output language
- Whether the user wants broad reputation, a specific topic, or a single disputed claim

If the user does not specify a time range, default to the period where public evidence is available and say so.

## 2. Collect Sources

Prioritize sources in this order:

1. Primary, dated material from the person
2. Full transcripts, recordings, papers, books, shareholder letters, filings, or long-form interviews
3. Archived versions of deleted or changed material
4. Reliable reporting that quotes or links primary sources
5. Commentary about the person, used only as context

For each source, preserve:

- URL or file path
- Publication date
- Author or speaker
- Medium
- Whether the evidence is primary or secondary
- Any access limitation

## 3. Extract Claims

Extract claims that are central, repeated, influential, or testable. Avoid over-indexing on offhand remarks unless the task is specifically about them.

For each claim, capture:

- Date
- Original quote or faithful paraphrase
- Context
- Claim type
- Time horizon if present
- Confidence level if stated
- Later evidence that confirms, weakens, or falsifies it

Use short compliant quotes when material is copyrighted. Summarize longer passages.

## 4. Build the Timeline

Order claims chronologically. Group by topic when the person has many claims across domains. Mark gaps where no reliable source was found.

Useful timeline questions:

- What did they say before the outcome was known?
- Did they maintain the view after contrary evidence?
- Did they revise the model clearly, quietly drift, or reverse without explanation?
- Did they acknowledge uncertainty or present speculation as certainty?

## 5. Verify Outcomes

Use later data, events, expert consensus, market outcomes, product history, or institutional records depending on the claim type. Prefer sources independent from the person being evaluated.

Do not force verification for value judgments, identity claims, or vague predictions. Label them as not verifiable or not yet testable.

## 6. Analyze Credibility Boundaries

Evaluate by domain:

- Strong domains: repeated accurate, testable claims with transparent reasoning
- Conditional domains: mixed record, narrow expertise, or context-specific usefulness
- Weak domains: repeated failures, unclear method, excessive certainty, or undisclosed incentives
- Unknown domains: insufficient evidence

Separate track record from moral judgment. A person can be accurate and ethically conflicted, or sincere but unreliable.

## 7. Write the Conclusion

Conclude only after evidence. State:

- What the person is reliable for
- What they are not reliable for
- How much evidence supports the judgment
- What could change the assessment

Use cautious language when the source base is thin.
